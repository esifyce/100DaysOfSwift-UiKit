//
//  ViewController.swift
//  16.Day-StormViewer
//
//  Created by Sabir Myrzaev on 20.10.2021.
//

import UIKit

class ViewController: UITableViewController {
    
    var pictures = [String]()
    var picDict = [String: Int]()
    
    // MARK: - lifecycle VC

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Storm Viewer"
        navigationController?.navigationBar.prefersLargeTitles = true

        let defaults = UserDefaults.standard
        if let savedData = defaults.object(forKey: "picDict") as? Data,
           let savedPictures = defaults.object(forKey: "pictures") as? Data {
            let jsonDecoder = JSONDecoder()
            
            do {
                picDict = try jsonDecoder.decode([String: Int].self, from: savedData)
                pictures = try jsonDecoder.decode([String].self, from: savedPictures)
            } catch {
                print("Failed to load people")
            }
        } else {
            performSelector(inBackground: #selector(loadPic), with: nil)
        }
        tableView.performSelector(onMainThread: #selector(UITableView.reloadData), with: nil, waitUntilDone: false)
    }
    
    
    // MARK: - Codable
    func save() {
        let jsonEncoder = JSONEncoder()
        if let savedData = try? jsonEncoder.encode(picDict),
           let savedPictures = try? jsonEncoder.encode(pictures) {
            let defaults = UserDefaults.standard
            defaults.set(savedData, forKey: "picDict")
            defaults.set(savedPictures, forKey: "pictures")
        } else {
            print("Failed to save picture")
        }
    }
    
    @objc func loadPic() {
        let fm = FileManager.default
        let path = Bundle.main.resourcePath!
        let items = try! fm.contentsOfDirectory(atPath: path)
        
        for item in items {
            if item.hasPrefix("nssl") {
                pictures.append(item)
                picDict[item] = 0
            }
        }
        pictures.sort()
    }
}
// MARK: - TableViewController
extension ViewController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pictures.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Picture", for: indexPath)
        let picture = pictures[indexPath.row]
        cell.textLabel?.text = pictures[indexPath.row]
        cell.detailTextLabel?.text = "\(picDict[picture]!)"
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "Detail") as? DetailViewController {
            
            vc.selectedImage = pictures[indexPath.row]
            vc.totalPictures = pictures.count
            vc.selectedPictureNumber = indexPath.row + 1
            
            
            
            navigationController?.pushViewController(vc, animated: true)
        }
        let picture = pictures[indexPath.row]
        picDict[picture]! += 1
        save()
        tableView.reloadData()
    }
}
